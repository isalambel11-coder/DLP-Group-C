# Data or Sample Input

This folder contains sample input information for the proposed Data Loss Prevention (DLP) research.

The project may use publicly available or synthetic data such as:
- Email or communication records
- Endpoint activity logs
- Network activity logs
- File access or transfer events
- Data classification examples

No confidential, private, or restricted organisational data should be included.
