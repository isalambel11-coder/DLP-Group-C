# Results or Expected Output

This folder contains the proposed/expected outputs of the Data Loss Prevention research.

Expected outputs may include:
- Detection/classification results
- Confusion matrix
- Accuracy, precision, recall and F1-score
- Tables and graphs
- Comparison of proposed and baseline approaches
- Expected system workflow/interface

Actual results must only be added after experiments are conducted.
